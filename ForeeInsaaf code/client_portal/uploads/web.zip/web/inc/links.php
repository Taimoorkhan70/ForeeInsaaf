<link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon" />

<link rel="stylesheet" href="assets/css/bootstrap.min.css" />

<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css" />
<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css" />

<link rel="stylesheet" href="assets/plugins/feather/feather.css" />

<link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
<link rel="stylesheet" href="assets/css/owl.theme.default.min.css" />

<link rel="stylesheet" href="assets/plugins/aos/aos.css" />

<link rel="stylesheet" href="assets/plugins/select2/css/select2.min.css" />

<link rel="stylesheet" href="assets/css/style.css" />
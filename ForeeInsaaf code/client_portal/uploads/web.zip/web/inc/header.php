<header class="header header-five">
                <nav class="navbar navbar-expand-lg header-nav">
                    <div class="navbar-header">
                        <a id="mobile_btn" href="javascript:void(0);">
                            <span class="bar-icon">
                                <span></span>
                                <span></span>
                                <span></span>
                            </span>
                        </a>
                        <a href="index.php" class="navbar-brand logo text-white">
                            <!-- <img src="assets/img/logo-white.png" class="img-fluid" alt="Logo" /> -->
                           <b><h1> FORI INSAF</h1></b>
                        </a>
                        <a href="index.php" class="navbar-brand logo scroll-logo">
                            <!-- <img src="assets/img/logo.png" class="img-fluid" alt="Logo" /> -->
                            <b><h1> FORI INSAF</h1></b>
                        </a>
                    </div>
                    <div class="main-menu-wrapper">
                        <div class="menu-header">
                            <a href="index.php" class="menu-logo">
                                <img src="assets/img/logo.png" class="img-fluid" alt="Logo" />
                            </a>
                            <a id="menu_close" class="menu-close" href="javascript:void(0);">
                                <i class="fas fa-times"></i>
                            </a>
                        </div>
                        <ul class="main-nav">
                            <li>
                                <a href="index.php">Home</a>
                            </li>
                            <li>
                                <a href="about.php">About</a>
                            </li>
                            <li>
                                <a href="coutact.php">Contact Us</a>
                            </li>
                            <li>
                                <a href="blogs.php">Blogs</a>
                            </li>
                        </ul>
                    </div>
                    <ul class="nav header-navbar-rht">
                        <li class="sign-reg"><a href="login.php" class="log-btn"> Sign in</a> <span class="space-login">/</span><a href="register.php" class="log-btn"> Register</a></li>
                        <?php
                        
                        ?>
                        <li><a href="post-project.php" class="login-btn">Post a Project </a></li>
                    </ul>
                </nav>
            </header>
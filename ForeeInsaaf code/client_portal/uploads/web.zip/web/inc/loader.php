<!-- <div id="global-loader">
            <div class="whirly-loader"></div>
            <div class="loader-img">
                <img src="assets/img/load-icon.svg" class="img-fluid" alt />
            </div>
        </div> -->
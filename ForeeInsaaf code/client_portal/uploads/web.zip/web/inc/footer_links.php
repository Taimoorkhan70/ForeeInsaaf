        <button class="scroll-top scroll-top-next scroll-to-target" data-target="html">
            <span class="ti-angle-up"><i class="feather-arrow-up"></i></span>
        </button>

        <script src="assets/js/jquery-3.6.1.min.js"></script>

        <script src="assets/js/bootstrap.bundle.min.js"></script>

        <script src="assets/js/owl.carousel.min.js"></script>

        <script src="assets/js/jquery.waypoints.js"></script>
        <script src="assets/js/jquery.counterup.min.js"></script>

        <script src="assets/plugins/aos/aos.js"></script>

        <script src="assets/plugins/select2/js/select2.min.js"></script>

        <script src="assets/js/slick.js"></script>

        <script src="assets/js/script.js"></script>